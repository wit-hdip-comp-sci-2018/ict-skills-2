import React, { Component, Fragment } from "react";
import { withRouter } from "react-router-dom";

class BaseInbox extends Component {
  render() {
    return (
      <Fragment>
        <h2>Inbox page</h2>
        <h3>Messages for user: {this.props.match.params.userId} </h3>
      </Fragment>
    );
  }
}
export default withRouter(BaseInbox);
