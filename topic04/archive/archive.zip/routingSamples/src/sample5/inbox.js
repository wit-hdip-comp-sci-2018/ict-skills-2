import React, { Component, Fragment } from "react";
import { withRouter, Route } from "react-router-dom";
import { Messages } from "../sample4/inbox";

class BaseInbox extends Component {
  render() {
    return (
      <Fragment>
        <h2>Inbox page</h2>
        <Messages id={this.props.match.params.userId} />
        <Route
          path={`/inbox/:id/statistics`}
          render={ (props) => {
            return <Stats {...props} usage={[5.4, 9.2]} />;
          }}
        />
        <Route path={`/inbox/:id/drafts`} component={Drafts} />
      </Fragment>
    );
  }
}

class Stats extends Component {
  render() {
    return (
      <Fragment>
        <h3>Statistical data for user: {this.props.match.params.id}</h3>
        <h4>Emails sent (per day) = {this.props.usage[0]} </h4>
        <h4>Emails received (per day) = {this.props.usage[1]} </h4>
      </Fragment>
    );
  }
}

class Drafts extends Component {
  render() {
    return <h3>Draft emails for user {this.props.match.params.id}</h3>;
  }
}

export default withRouter(BaseInbox);
