import React, { Component, Fragment } from "react";
import ReactDOM from "react-dom";
import { BrowserRouter, Route, Redirect, Switch, Link } from "react-router-dom";
import Inbox from "./inbox";

class App extends Component {
  render() {
    return (
      <Fragment>
        <h1>Home page</h1>
        <h3>Demo Alternative Route API</h3>
        <p>Used for passing custom props to a Route's component</p>
        <p>
          Try{" "}
          <Link to='/inbox/1234/statistics'>User 1234</Link>
          <span> - Inbox and nested route with custom props.</span>{" "}
        </p>
        <p>
          Try <Link to='/inbox/4321/drafts'>User 4321</Link>
          <span> - Inbox and standard nested route approach.</span>{" "}
        </p>
      </Fragment>
    );
  }
}

class Router extends Component {
  render() {
    return (
      <BrowserRouter>
        <Switch>
          <Route path="/inbox/:userId" component={Inbox} />
          <Route exact path="/" component={App} />
          <Redirect from="*" to="/" />
        </Switch>
      </BrowserRouter>
    );
  }
}

ReactDOM.render(<Router />, document.getElementById("root"));
