import React, {Component, Fragment} from 'react';
import ReactDOM from 'react-dom';
import { BrowserRouter, Route, Redirect, Switch, Link } from 'react-router-dom';
import {About} from '../sample1';
import Inbox from '../sample3/inbox';

import Register from '../sample7';
import Header from './header';
import Footer from './footer';
import '../../node_modules/bootstrap/dist/css/bootstrap.css';
import './app.css';

class Home extends Component { 
    render() {  
        return ( 
            <Fragment> 
                <h1>Home page</h1>
                <h4>Try link: <Link to="/inbox/1234">user 1234</Link></h4>
            </Fragment>
        )
    }
}

class Contact extends Component { 
    render() {  
        return  <h2>Contact Us page</h2>
    }
}

class Router extends Component { 
    render() {  
        return (
            <BrowserRouter>
              <div>
                <Header/>
                <div className="container">
                    <Switch>
                        <Route path='/about' component={ About } />
                        <Route path='/register' component={ Register } />
                        <Route path='/contact' component={ Contact } />
                        <Route path='/inbox/:userId' component={ Inbox } />
                        <Route exact path='/' component={ Home } />
                        <Redirect from='*' to='/' />
                    </Switch>
                </div>
                <Footer />
              </div>
            </BrowserRouter>
        )
    }
}

ReactDOM.render(<Router/>,
     document.getElementById('root'))