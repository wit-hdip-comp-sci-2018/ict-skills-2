import React, { Component } from "react";
import { Link } from "react-router-dom";

class Header extends Component {
  render() {
    return (
      <nav className="navbar navbar-dark fixed-top  bg-dark ">
        <Link className="navbar-brand" to="/">
          Company Name
        </Link>
        <ul className="navbar-nav d-flex flex-row">
          <li className="p-2">
            <Link className="text-white" to="/">
              Home
            </Link>
          </li>
          <li className="p-2">
            <Link className="text-white" to="/about">
              About
            </Link>
          </li>
          <li className="p-2">
            <Link className="text-white" to="#">
              Nav A
            </Link>
          </li>
          <li className="p-2">
            <Link className="text-white" to="#">
              Nav B
            </Link>
          </li>
          <li className="p-2">
            <Link className="text-white" to="/register">
              Register
            </Link>
          </li>
        </ul>
      </nav>
    );
  }
}

export default Header;
