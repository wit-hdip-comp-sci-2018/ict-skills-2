import React, { Component, Fragment } from "react";
import ReactDOM from "react-dom";
import { BrowserRouter, Route, Redirect, Switch, Link } from "react-router-dom";
import { About } from "../sample1";

class Inbox extends Component {
  render() {
    const { alpha, beta } = this.props.location.state;
    return (
      <Fragment>
        <h2>Inbox page</h2>
        <p>{`Props: ${alpha}, ${beta}`}</p>
      </Fragment>
    );
  }
}

class App extends Component {
  render() {
    return (
      <Fragment>
        <ul>
          <li>
            <Link to="/about">About</Link>
          </li>
          <li>
            <Link
              to={{
                pathname: "/inbox",
                state: {
                  alpha: "A",
                  beta: "something else"
                }
              }}
            >
              Inbox
            </Link>
            <span> (extra props)</span>{" "}
          </li>
        </ul>
        <h1>Home page</h1>
        <h3>Demos passing additional props with a Link</h3>
      </Fragment>
    );
  }
}

class Router extends Component {
  render() {
    return (
      <BrowserRouter>
        <Switch>
          <Route path="/about" component={About} />
          <Route path="/inbox" component={Inbox} />
          <Route exact path="/" component={App} />
          <Redirect from="*" to="/" />
        </Switch>
      </BrowserRouter>
    );
  }
}

ReactDOM.render(<Router />, document.getElementById("root"));
