import React, { Component } from "react";
import ReactDOM from "react-dom";
import { BrowserRouter, Route, Redirect, Switch, Link } from "react-router-dom";

// Authentication utility

const fakeAuth = {
  isAuthenticated: false,
  authenticate(username,cb) {
    this.isAuthenticated = true
    setTimeout(cb, 100) // fake async
  },
  signout(cb) {
    this.isAuthenticated = false
    setTimeout(cb, 100) // fake async
  }
}

// Authentication components

class PrivateRoute extends Component {
  render() { 
    const { component: Component, ...rest } = this.props ;
    return ( 
      <Route { ...rest} render={ (props) =>  
         fakeAuth.isAuthenticated === true ?
           <Component {...props} />  :
           <Redirect to='/login' /> 
         } 
       />
    )
  }
}

// PAGES

class Login extends Component {
  render() {
    return <h2>Login</h2>;
  }
}

const Public = () => <h2>Public page</h2>;

const Protected = () => <h2>Protected page</h2>;

const Home = () => <h2>Home page</h2>;

// Routing Configuration

class Router extends Component {
  render() {
    return (
      <BrowserRouter>
        <div>
          <ul>
            <li>
              <Link to="/">Home</Link>
            </li>
            <li>
              <Link to="/public">Public</Link>
            </li>
            <li>
              <Link to="/protected">Protected</Link>
            </li>
          </ul>
          <Switch>
            <Route path="/public" component={Public} />
            <PrivateRoute path="/protected" component={Protected} />
            <Route path="/login" component={Login} />
            <Route exact path="/" component={Home} />
            <Redirect from="*" to="/" />
          </Switch>
        </div>
      </BrowserRouter>
    );
  }
}

ReactDOM.render(<Router />, document.getElementById("root"));
