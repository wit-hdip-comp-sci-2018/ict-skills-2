const rootElement = 
    <div className='otherCSSstyle' >
        <h1 className='myCSSstyle' >Languages</h1>
        <ul>
            <li>Ruby</li>
            <li>Javascript</li>
        </ul>                                     
    </div> ;

ReactDOM.render(rootElement,  
    document.getElementById('mount-point') );