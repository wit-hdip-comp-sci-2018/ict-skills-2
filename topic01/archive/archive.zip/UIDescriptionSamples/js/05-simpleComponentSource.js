
class DynamicLanguages extends React.Component { 
    render() {
        return (
            <div className='otherCSSstyle' >
                <h1 className='myCSSstyle'>Dynamic Languages (Component)</h1>
                <ul>
                    <li>Python</li>
                    <li>Javascript</li>
                </ul>                                     
            </div>
        );
    }
}

ReactDOM.render(
    <DynamicLanguages/> ,
    document.getElementById('mount-point')) ;
